namespace CoreApi.DTO {
    public class TokenBlackList
        {
            public int Id { get; set; }
            public string Token { get; set; }
        }
}